import os
from modelos.avaliacao import Avaliacao
from modelos.cardapio.item_cardapio import Item_cardapio


class Restaurante:
    restaurantes = []
    
    def __init__(self, nome, categoria):
        self.nome = nome.title()
        self.categoria = categoria.upper()
        self._ativo = False
        self._avaliacao = []
        self.cardapio = []
        Restaurante.restaurantes.append(self)

    def __str__(self):
        return f'Nome: {self.nome} | Categoria: {self.categoria} | Ativo: {self.ativo}'

    @classmethod
    def listar_restaurantes(cls):
        if len(Restaurante.restaurantes) > 0:
            os.system('cls')
            print('Nome do restaurante'.ljust(20), '| Categoria'.ljust(20), '| Media de avaliações'.ljust(20), '| Status de ativação')
            print('-' * 85)
            for i, restaurante in enumerate(Restaurante.restaurantes):
                nome_restaurante = restaurante.nome
                categoria_cadastrada = restaurante.categoria
                media_avaliacao = restaurante.media_avaliacao

                print(f'{i+1}. {nome_restaurante.ljust(20)} | {categoria_cadastrada.ljust(20)} | {str(media_avaliacao).ljust(20)} | {restaurante.ativo}')
            print('-' * 85)
            acessar_cardapio = input('Deseja acessar o cardápio de algum restaurante? (s/n) ')
            if acessar_cardapio == 's':
                opcao = int(input('Digite o número do restaurante que deseja acessar o cardápio: ')) - 1
                restaurante = Restaurante.restaurantes[opcao]
                restaurante.exibir_cardapio

        else:
            print('Nenhum restaurante cadastrado.')
        print('')
    

    def acessar_cardapio(self):
        self.exibir_cardapio



    @property
    def ativo(self):
        return '✅' if self._ativo else '❌'
    
    def alternar_estado(self):
        self._ativo = not self._ativo

    def avaliar(self, cliente, nota):
        if nota < 0:
            nota = 0
        elif nota > 5:
            nota = 5
        

        avaliacao = Avaliacao(cliente, nota)
        self._avaliacao.append(avaliacao)

    
    @property
    def media_avaliacao(self):
        if not self._avaliacao:
            return 'Restaurante não avaliado.'
        else:
            total = sum([avaliacao.nota for avaliacao in self._avaliacao])
            qtd_avaliacoes = len(self._avaliacao)
            media = round(total / qtd_avaliacoes, 1)
            return f'Média de avaliação: {media:.1f}'
        
    def adicionar_item_no_cardapio(self, item):
        if isinstance(item, Item_cardapio):
            self.cardapio.append(item)
    

    @property
    def exibir_cardapio(self):
        os.system('cls')
        print(f'Cardápio do restaurante {self.nome}')
        print('-' * 100) 
        for i,item in enumerate(self.cardapio,1):
            
            if hasattr(item, 'tamanho'):
               mensagem = f'{i}. Nome: {item.nome} | Preço: R${item.preco:.2f} | Tamanho: {item.tamanho}ml'
            else:
                mensagem = f'{i}. Nome: {item.nome} | Preço: R${item.preco:.2f} | Descrição: {item.descricao}'
            print(mensagem)
            print('-' * 100)
