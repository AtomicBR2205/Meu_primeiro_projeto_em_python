import os  # Importa a biblioteca os
from modelos.restaurante import Restaurante  # Importa a classe Restaurante

# Inicializa a lista de restaurantes com instâncias da classe Restaurante
restaurante_pizzaria_alpha = Restaurante('Pizzaria Alpha', 'Pizzaria')
restaurante_pizzaria_alpha.avaliar('João', 25)
restaurante_pizzaria_alpha.avaliar('Maria', 34)
restaurante_pizzaria_alpha.avaliar('José', -13)
restaurante_pizzaria_alpha.avaliar('Ana', 2)

restaurante_sushi_beta = Restaurante('Sushi Beta', 'Sushi')

def exibir_nome_do_programa():
    print('''
██████████████████████████████████████████████████████████████████████████
█─▄▄▄▄██▀▄─██▄─▄─▀█─▄▄─█▄─▄▄▀███▄─▄▄─█▄─▀─▄█▄─▄▄─█▄─▄▄▀█▄─▄▄─█─▄▄▄▄█─▄▄▄▄█
█▄▄▄▄─██─▀─███─▄─▀█─██─██─▄─▄████─▄█▀██▀─▀███─▄▄▄██─▄─▄██─▄█▀█▄▄▄▄─█▄▄▄▄─█
▀▄▄▄▄▄▀▄▄▀▄▄▀▄▄▄▄▀▀▄▄▄▄▀▄▄▀▄▄▀▀▀▄▄▄▄▄▀▄▄█▄▄▀▄▄▄▀▀▀▄▄▀▄▄▀▄▄▄▄▄▀▄▄▄▄▄▀▄▄▄▄▄▀
      ''')

def menu_principal():
    print('1. Cadastrar restaurante')
    print('2. Listar restaurantes')
    print('3. Ativar/desativar restaurante')
    print('4. Sair\n')

def pull_main():
    input('\nPressione ENTER para continuar... \n')
    main()

def sub_titulo(titulo):
    os.system('cls')
    linha = '-' * len(titulo)
    print(linha)
    print(titulo)
    print(linha)
    print('')

def ativar_restaurante():
    sub_titulo('Lista de restaurantes')
    Restaurante.listar_restaurantes()

    try:
        op_ativar = int(input('Digite o número do restaurante que deseja ativar/desativar: ')) - 1
        restaurante = Restaurante.restaurantes[op_ativar]
        restaurante.alternar_estado()
        estado = 'ativado' if restaurante._ativo else 'desativado'
        print(f'Restaurante {restaurante.nome} {estado} com sucesso!\n')
    except (IndexError, ValueError):
        print('Opção inválida. Tente novamente.\n')

    pull_main()

def sair_app():
    os.system('cls')
    print('Saindo do app...\n')

def cadastro_restaurante():
    sub_titulo('Cadastro de restaurante')
    nome_restaurante = input('Digite o nome do restaurante: ')
    categoria_restaurante = input(f'Digite a categoria do {nome_restaurante}: ')
    Restaurante(nome_restaurante, categoria_restaurante)
    print(f'Restaurante {nome_restaurante} cadastrado com sucesso!\n')
    pull_main()

def listar_restaurantes():
    sub_titulo('Lista de restaurantes')
    Restaurante.listar_restaurantes()
    pull_main()

def opicao_invalida():
    print('Opção inválida. Tente novamente.\n')
    pull_main()

def escolher_opcao():
    try:
        op_escolhida = int(input('Digite uma opção: \n'))

        if op_escolhida == 1:
            cadastro_restaurante()
        elif op_escolhida == 2:
            listar_restaurantes()
        elif op_escolhida == 3:
            ativar_restaurante()
        elif op_escolhida == 4:
            sair_app()
        else:
            opicao_invalida()
    except ValueError:
        opicao_invalida()

def main():
    exibir_nome_do_programa()
    menu_principal()
    escolher_opcao()

if __name__ == '__main__':
    main()