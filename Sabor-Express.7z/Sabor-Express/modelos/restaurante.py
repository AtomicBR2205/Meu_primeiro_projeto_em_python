from modelos.avaliacao import Avaliacao

class Restaurante:
    restaurantes = []
    
    def __init__(self, nome, categoria):
        self.nome = nome.title()
        self.categoria = categoria.upper()
        self._ativo = False
        self._avaliacao = []
        Restaurante.restaurantes.append(self)

    def __str__(self):
        return f'Nome: {self.nome} | Categoria: {self.categoria} | Ativo: {self.ativo}'

    @classmethod
    def listar_restaurantes(cls):
        if len(Restaurante.restaurantes) > 0:
            print('Nome do restaurante'.ljust(20), '| Categoria'.ljust(20), '| Media de avaliações'.ljust(20), '| Status de ativação')
            print('-' * 85)
            for i, restaurante in enumerate(Restaurante.restaurantes):
                nome_restaurante = restaurante.nome
                categoria_cadastrada = restaurante.categoria
                media_avaliacao = restaurante.media_avaliacao

                print(f'{i+1}. {nome_restaurante.ljust(20)} | {categoria_cadastrada.ljust(20)} | {str(media_avaliacao).ljust(20)} | {restaurante.ativo}')
            print('-' * 85)
        else:
            print('Nenhum restaurante cadastrado.')
        print('')
    
    @property
    def ativo(self):
        return '✅' if self._ativo else '❌'
    
    def alternar_estado(self):
        self._ativo = not self._ativo

    def avaliar(self, cliente, nota):
        if nota < 0:
            nota = 0
        elif nota > 5:
            nota = 5
        else:
            mensagem = 'Nota registrada com sucesso.'

        avaliacao = Avaliacao(cliente, nota)
        self._avaliacao.append(avaliacao)
        return mensagem
    
    @property
    def media_avaliacao(self):
        if not self._avaliacao:
            return 'Restaurante não avaliado.'
        else:
            total = sum([avaliacao.nota for avaliacao in self._avaliacao])
            qtd_avaliacoes = len(self._avaliacao)
            media = round(total / qtd_avaliacoes, 1)
            return f'Média de avaliação: {media:.1f}'